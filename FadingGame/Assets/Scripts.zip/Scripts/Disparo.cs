using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Jobs;

public class Disparo : MonoBehaviour
{
    //variaveis
     public float velocdisparo = 12.0f ;
     public float time = 0.0f;
    void Start()
    {
        //quando o jogo iniciar

    }

    void Update()
    {
        //quando o jogo tiver acontecendo
        transform.Translate(Vector3.right * velocdisparo * Time.deltaTime);


        // pra fazer ele sumir dps (aqui uma base pra vc ferle)
        time += Time.deltaTime;
        if ( time > 2.0f){Destroy(this.gameObject);}
        if ( transform.position.x  > 46.5f) {
            Destroy(this.gameObject);
        }
    }
}
