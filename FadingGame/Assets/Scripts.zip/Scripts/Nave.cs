using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nave : MonoBehaviour
{
    // variaveis da movmentação
    public float velocidade = 0.0f;
    public float entradaHorizontal;
    public float variaZ;
    // caixa de seleção pra colocar o prefb do dardo
    public GameObject Dardo;

    //variaveis do dardo
    public float tempoDeDisparo = 0.3f ;
    public float podeDisparar = 0.0f ;

    //rotação 
    public float angulo1 = 90.0f;
    public float suave = 5.0f;
    void Start()
    {
        // quando inicia o jogo
        Debug.Log("Start de " + this.name);
        velocidade = 10.0f;
    }
    void Update()
    {
        //quando o jogo estiver acontecendo
        //cria o bloco do codigos do movmento 
        Movimento();
        // disparo
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)){
            if ( Time.time > podeDisparar ){
                Instantiate(Dardo,transform.position + new Vector3(0,0,0),Quaternion.identity);
                podeDisparar = Time.time + tempoDeDisparo ;
            }
        }
    }
    //bloco isoolado de codigos do movimento
    private void Movimento(){
        //movimento no eixo x
        entradaHorizontal = Input.GetAxis("Horizontal");
        transform.Translate(Vector3.right * Time.deltaTime * velocidade * entradaHorizontal);
        //limitar movimento no eixo x 
        if ( transform.position.x  > 43.5f) {
            transform.position = new Vector3(43.5f,transform.position.y,0);
        }
        if ( transform.position.x  < -43.5f  ) {
            transform.position = new Vector3(-43.5f,transform.position.y,0);
        }
        //movimento no eixo y


        variaZ = Input.GetAxis("Vertical") * angulo1;
        Quaternion target = Quaternion.Euler (0,0, variaZ);
        transform.rotation = new Vector3 (target, target, Time.deltaTime * suave);
        //limitar movimento no eixo y
        if ( transform.position.y  > 16.2f ) {
            transform.position = new Vector3(transform.position.x,16.2f,0);
        }
        if ( transform.position.y  < -10.9f  ) {
            transform.position = new Vector3(transform.position.x,-10.9f,0);
        }
    }
}
