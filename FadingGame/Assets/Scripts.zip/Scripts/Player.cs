using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Jobs;
public class Player : MonoBehaviour
{
    // variaveis da movmentação
    public float velocidade = 0.0f;
    public float entradaHorizontal;
    public float entradaVertical;

    // caixa de seleção pra colocar o prefb do dardo
    public GameObject Dardo;

    //variaveis do dardo
    public float tempoDeDisparo = 0.3f ;
    public float podeDisparar = 0.0f ;

    //rotação 
    public float suave = 5.0f;
    public float angulo = 90.0f;
    public float angulo1 = 180f;
    
    void Start()
    {
        // quando inicia o jogo
        Debug.Log("Start de " + this.name);
        velocidade = 10.0f;
    }
    void Update()
    {
        //quando o jogo estiver acontecendo

        //cria o bloco do codigos do movmento 
        Movimento();
        

        // disparo
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)){
            if ( Time.time > podeDisparar ){
                Instantiate(Dardo,transform.position + new Vector3(0,0,0),Quaternion.identity);
                podeDisparar = Time.time + tempoDeDisparo ;
            }
        }
        
        
        

    }

    //bloco isoolado de codigos do movimento
    private void Movimento(){
        //movimento no eixo x
        entradaHorizontal = Input.GetAxis("Horizontal");
        transform.Translate(Vector3.right * Time.deltaTime * velocidade * entradaHorizontal);
    
        //limitar movimento no eixo x 
        if ( transform.position.x  > 43.5f) {
            transform.position = new Vector3(43.5f,transform.position.y,0);
        }
        if ( transform.position.x  < -43.5f  ) {
            transform.position = new Vector3(-43.5f,transform.position.y,0);
        }
        //movimento no eixo y
        entradaVertical = Input.GetAxis("Vertical");
        transform.Translate(Vector3.up * Time.deltaTime * velocidade * entradaVertical);
        //limitar movimento no eixo y
        if ( transform.position.y  > 16.2f ) {
            transform.position = new Vector3(transform.position.x,16.2f,0);
        }
        if ( transform.position.y  < -10.9f  ) {
            transform.position = new Vector3(transform.position.x,-10.9f,0);
        }

        /*rotação
        float anguloX = Input.GetAxis("Horizontal") * angulo1;
        float anguloZ = Input.GetAxis("Vertical") * angulo;
        Quaternion target = Quaternion.Euler (0,0, anguloZ);
        Quaternion target1 = Quaternion.Euler (0, 0, anguloX);
        //amortece a rotação    
        transform.rotation = new Vector3(target, target, Time.deltaTime * suave);
        */
    
    }

}
